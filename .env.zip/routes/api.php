<?php

use App\Http\Controllers\Api\Generals\ActivityController;
use App\Http\Controllers\Api\Generals\BankController;
use App\Http\Controllers\Api\Generals\CityController;
use App\Http\Controllers\Api\Generals\CountryController;
use App\Http\Controllers\Api\Generals\LanguageController;
use App\Http\Controllers\Api\Generals\NeighborhoodController;
use App\Http\Controllers\Api\Generals\NurseryServiceTypeController;
use App\Http\Controllers\Api\Generals\PackagesTypeController;
use App\Http\Controllers\Api\Generals\QualificationController;
use App\Http\Controllers\Api\Nurseries\NurseryController;
use App\Http\Controllers\Api\Users\Auth\RestPasswordController;
use App\Http\Controllers\Api\Users\Auth\UserAuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;




Route::group(['as' => 'api.', 'middleware' => ['cors', 'json.response']], function () {

    // Public
    Route::post('/register', [UserAuthController::class, 'register'])->name('register.api');
    Route::post('/login', [UserAuthController::class, 'login'])->name('login.api');

    Route::post('/confirm-phone-number', [RestPasswordController::class, 'checkPhone']);
    Route::post('/reset-verification', [RestPasswordController::class, 'verifyToReset']);
    Route::post('/reset-password', [RestPasswordController::class, 'passwordReset']);
});


Route::group(['as' => 'api.', 'middleware' => ['cors', 'json.response', 'auth:api']], function () {

    //Auth
    Route::post('/logout', [UserAuthController::class, 'logout']);
    Route::post('/resend', [UserAuthController::class, 'resendOTP']);
    Route::post('/verify', [UserAuthController::class, 'verifyOTP']);


    // Generals
    Route::apiResource('countries', CountryController::class);
    Route::apiResource('cities', CityController::class);
    Route::apiResource('neighborhoods', NeighborhoodController::class);
    Route::apiResource('qualifications', QualificationController::class);
    Route::apiResource('languages', LanguageController::class);
    Route::apiResource('banks', BankController::class);
    Route::apiResource('nursery-services-types', NurseryServiceTypeController::class);
    Route::apiResource('packages-type', PackagesTypeController::class);
    Route::apiResource('activities', ActivityController::class);

    // Nurseries
    Route::apiResource('nurseries', NurseryController::class);
});
