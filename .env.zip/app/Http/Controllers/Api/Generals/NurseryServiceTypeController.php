<?php

namespace App\Http\Controllers\Api\Generals;

use App\Helpers\JsonResponse;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Generals\NurseryServiceTypeRequest;
use App\Http\Resources\Api\Generals\NurseryServiceTypeResource;
use App\Models\Api\Generals\NurseryServiceType;
use App\Repositories\Interfaces\Api\Generals\INurseryServiceTypeRepository;

class NurseryServiceTypeController extends Controller
{
    private $nurseryServiceTypeRepository;

    public function __construct(INurseryServiceTypeRepository $nurseryServiceTypeRepository)
    {
        $this->nurseryServiceTypeRepository = $nurseryServiceTypeRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            return JsonResponse::successfulResponse('', NurseryServiceTypeResource::collection($this->nurseryServiceTypeRepository->fetchAll()));
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NurseryServiceTypeRequest $request)
    {
        return JsonResponse::successfulResponse('created_succssfully', $this->nurseryServiceTypeRepository->create($request->validated()));
    }

    /**
     * Display the specified resource.
     *
     * @param  NurseryServiceType $nurseryServiceType
     * @return \Illuminate\Http\Response
     */
    public function show(NurseryServiceType $nurseryServicesType)
    {
        try {
            $nurseryServiceType = new NurseryServiceTypeResource($nurseryServicesType);
            return JsonResponse::successfulResponse('succss', $nurseryServiceType);
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  NurseryServiceType $nurseryServiceType
     * @return \Illuminate\Http\Response
     */
    public function update(NurseryServiceTypeRequest $request, NurseryServiceType $nurseryServicesType)
    {
        try {
            $this->nurseryServiceTypeRepository->update($request->validated(), $nurseryServicesType['id']);
            return JsonResponse::successfulResponse('updated_succssfully');
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  NurseryServiceType $nurseryServiceType
     * @return \Illuminate\Http\Response
     */
    public function destroy(NurseryServiceType $nurseryServicesType)
    {
        try {
            $this->nurseryServiceTypeRepository->delete($nurseryServicesType['id']);
            return JsonResponse::successfulResponse('deleted_succssfully');
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }
}
