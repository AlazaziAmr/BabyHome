<?php

namespace App\Http\Controllers\Api\Users\Auth;

use App\Helpers\JsonResponse;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Users\UserLoginRequest;
use App\Http\Requests\Api\Users\UserRegistrationRequest;
use App\Http\Resources\Api\Users\UserResource;
use App\Models\User;
use App\Repositories\Interfaces\Api\Users\IUserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserAuthController extends Controller
{

    private $userRepository;

    public function __construct(IUserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }


    public function VerfiedUserWithToken($user)
    {
        $response = ['token' => $user->createToken('Baby Home Client')->accessToken];
        return (new UserResource($user))->additional(array_merge(['data' => $response], JsonResponse::success()));
    }
    public function userWithToken($user)
    {
        $response = ['token' => $user->createToken('Baby Home Client')->accessToken];
        return (new UserResource($user))->additional(array_merge(['data' => $response], JsonResponse::sentSuccssfully()));
    }
    /**
     * User registerion
     *
     * @param Request $request
     *
     * @return UserResource
     */
    public function register(UserRegistrationRequest $request)
    {
        try {
            $data = $request->validated();
            $data['activation_code'] = OTPGenrator();
            $user = $this->userRepository->register($data);
            // sendOTP($user['activation_code'], $user['phone'],$message = '');
            return $this->userWithToken($user);
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }


    /**
     *user login
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function login(UserLoginRequest $request)
    {
        try {
            $user =  $this->userRepository->findBy('phone', $request['phone']);

            if ($user) {
                if (!$user['is_verified']) {
                    $user->update(['activation_code' => OTPGenrator()]);
                    // sendOTP($user['activation_code'], $user['phone'],$message = '');
                    if (Hash::check($request['password'], $user['password'])) {
                        return $this->userWithToken($user);
                    } else {
                        return JsonResponse::errorResponse('password_mismatch');
                    }
                }
                if (Hash::check($request['password'], $user['password'])) {
                    return $this->VerfiedUserWithToken($user);
                } else {
                    return JsonResponse::errorResponse('password_mismatch');
                }
            } else {
                return JsonResponse::errorResponse('user_does_not_exist');
            }
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     *logout
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function logout()
    {
        try {
            $token = user()->token();
            $token->revoke();
            return JsonResponse::successfulResponse('successful_log_out');
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }



    /**
     *resend OTP
     *
     * @param Request $request
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\Routing\ResponseFactory|\Illuminate\Http\Response
     */
    public function resendOTP(Request $request)
    {
        try {
            $user =  $this->userRepository->findBy('phone', $request['phone']);
            if ($user) {
                $user->update(['activation_code' => OTPGenrator()]);
                // sendOTP($user['activation_code'], $user['phone'],$message = '');
                return JsonResponse::successfulResponse('sent_successfully');
            } else {
                return JsonResponse::errorResponse('phone_number_is_not_registered');
            }
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    public function verifyOTP(Request $request)
    {
        try {
            // $user =  $this->userRepository->findByMultipleAttributes('phone', $request['phone']);

            $user = User::where('phone', $request['phone'])->where(
                'activation_code',
                $request['activation_code']
            )->first();
            if ($user) {
                $user->update(['is_verified' => 1]);
                return JsonResponse::successfulResponse('verifide_successfully');
            } else {
                return JsonResponse::errorResponse('invalid_verification_code');
            }
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }
}
