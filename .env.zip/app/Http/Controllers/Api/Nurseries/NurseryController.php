<?php

namespace App\Http\Controllers\Api\Nurseries;

use App\Helpers\JsonResponse;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\Nurseries\NurseryRequest;
use App\Http\Resources\Api\Nurseries\NurseryResource;
use App\Models\Api\Nurseries\Nursery;
use App\Repositories\Interfaces\Api\Nurseries\INurseryRepository;
use Illuminate\Http\Request;

class NurseryController extends Controller
{
    private $nurseryRepository;

    public function __construct(INurseryRepository $nurseryRepository)
    {
        $this->nurseryRepository = $nurseryRepository;
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        try {
            return JsonResponse::successfulResponse('', NurseryResource::collection($this->nurseryRepository->fetchAll()));
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(NurseryRequest $request)
    {
        return JsonResponse::successfulResponse('created_succssfully', $this->nurseryRepository->createRequset($request->validated()));
    }

    /**
     * Display the specified resource.
     *
     * @param  Nursery $nursery
     * @return \Illuminate\Http\Response
     */
    public function show(Nursery $nurseries)
    {
        try {
            $nurseries = new NurseryResource($nurseries);
            return JsonResponse::successfulResponse('succss', $nurseries);
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  Nursery $nursery
     * @return \Illuminate\Http\Response
     */
    public function update(NurseryRequest $request, Nursery $nurseries)
    {
        try {
            $this->nurseryRepository->update($request->validated(), $nurseries['id']);
            return JsonResponse::successfulResponse('updated_succssfully');
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  Nursery $nursery
     * @return \Illuminate\Http\Response
     */
    public function destroy(Nursery $nurseries)
    {
        try {
            $this->nurseryRepository->delete($nurseries['id']);
            return JsonResponse::successfulResponse('deleted_succssfully');
        } catch (\Exception $e) {
            return JsonResponse::errorResponse($e->getMessage());
        }
    }
}
