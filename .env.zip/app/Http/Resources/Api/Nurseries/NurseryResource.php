<?php

namespace App\Http\Resources\Api\Nurseries;

use App\Http\Resources\Api\Generals\CityResource;
use App\Http\Resources\Api\Generals\CountryResource;
use App\Http\Resources\Api\Generals\NeighborhoodResource;
use Illuminate\Http\Resources\Json\JsonResource;

class NurseryResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'capacity' => $this->capacity,
            'acceptance_age' => $this->acceptance_age,
            'country' => new CountryResource($this->country),
            'city' => new CityResource($this->city),
            'neighborhood' => new NeighborhoodResource($this->neighborhood),
            'street_number' => $this->street_number,
            'address_description' => $this->address_description,
            "location" => [
                "latitude" => $this->latitude,
                "longitude" => $this->longitude
            ],
            'disabilities_acceptance' => $this->disabilities_acceptance,
            'is_active' => $this->is_active,
        ];
    }
}
