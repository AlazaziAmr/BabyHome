<?php

namespace App\Http\Requests\Api\Nurseries;

use Illuminate\Foundation\Http\FormRequest;

class NurseryRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name.en' => 'required|string',
            'name.ar' => 'required|string',
            'capacity'      => 'required|numeric',
            'acceptance_age'      => 'required|string',
            'country_id'      => 'required|exists:countries,id',
            'city_id'      => 'required|exists:cities,id',
            'neighborhood_id'      => 'required|exists:neighborhoods,id',
            'street_number' => 'required|string',
            'address_description' => 'required|string',
            'latitude' => 'required|between:0,99.99',
            'longitude' => 'required|between:0,99.99',
            'disabilities_acceptance' => 'required|boolean',
            'is_active' => 'required|boolean',

            // personal Info
            'years_of_experince' => 'required|numeric',
            'date_of_birth' => 'required|date',
            'academic_qualifications' => 'required|array',
            'academic_qualifications.*' => 'required|string',
            'attachments' => 'required|array',
            'attachments.*.title' => 'required|string',
            'attachments.*.description' => 'required|string',
            'attachments.*.file' => 'required|mimes:jpeg,png,jpg,gif,pdf',
            'languages'      => 'required|array',

            // packages
            'packages' => 'required|array',
            'packages.*.name.en' => 'required|string',
            'packages.*.name.ar' => 'required|string',
            'packages.*.description' => 'required|string',
            'packages.*.type_id' => 'required|exists:packages_types,id',
            'packages.*.days.*' => 'required|exists:days,id',
            'packages.*.capacity' => 'required|numeric',
            'packages.*.from_hour' => 'required|date_format:H:i',
            'packages.*.to_hour' => 'required|date_format:H:i',
            'packages.*.total_price' => 'required|numeric',
            'packages.*.bundle_renew_after' => 'required|boolean',
            'packages.*.is_active' => 'required|boolean',

            // activities
            'activities.*' => 'required|exists:activities,id',
        ];
    }
}
