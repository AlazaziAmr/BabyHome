<?php

namespace App\Providers;

use App\Repositories\Classes\Api\Generals\ActivityRepository;
use App\Repositories\Classes\Api\Generals\BankRepository;
use App\Repositories\Classes\Api\Generals\CityRepository;
use App\Repositories\Classes\Api\Generals\CountryRepository;
use App\Repositories\Classes\Api\Generals\LanguageRepository;
use App\Repositories\Classes\Api\Generals\NeighborhoodRepository;
use App\Repositories\Classes\Api\Generals\NurseryServiceTypeRepository;
use App\Repositories\Classes\Api\Generals\PackagesTypeRepository;
use App\Repositories\Classes\Api\Generals\QualificationRepository;
use App\Repositories\Classes\Api\Nurseries\NurseryRepository;
use App\Repositories\Classes\Api\Users\UserRepository;
use App\Repositories\Interfaces\Api\Generals\IActivityRepository;
use App\Repositories\Interfaces\Api\Generals\IBankRepository;
use App\Repositories\Interfaces\Api\Generals\ICityRepository;
use App\Repositories\Interfaces\Api\Generals\ICountryRepository;
use App\Repositories\Interfaces\Api\Generals\ILanguageRepository;
use App\Repositories\Interfaces\Api\Generals\INeighborhoodRepository;
use App\Repositories\Interfaces\Api\Generals\INurseryServiceTypeRepository;
use App\Repositories\Interfaces\Api\Generals\IPackagesTypeRepository;
use App\Repositories\Interfaces\Api\Generals\IQualificationRepository;
use App\Repositories\Interfaces\Api\Nurseries\INurseryRepository;
use App\Repositories\Interfaces\Api\Users\IUserRepository;
use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(IUserRepository::class, UserRepository::class);
        $this->app->bind(ICountryRepository::class, CountryRepository::class);
        $this->app->bind(ICityRepository::class, CityRepository::class);
        $this->app->bind(INeighborhoodRepository::class, NeighborhoodRepository::class);
        $this->app->bind(IQualificationRepository::class, QualificationRepository::class);
        $this->app->bind(ILanguageRepository::class, LanguageRepository::class);
        $this->app->bind(IBankRepository::class, BankRepository::class);
        $this->app->bind(INurseryServiceTypeRepository::class, NurseryServiceTypeRepository::class);
        $this->app->bind(IPackagesTypeRepository::class, PackagesTypeRepository::class);
        $this->app->bind(IActivityRepository::class, ActivityRepository::class);
        $this->app->bind(INurseryRepository::class, NurseryRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
