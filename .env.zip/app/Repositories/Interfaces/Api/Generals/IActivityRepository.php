<?php

namespace App\Repositories\Interfaces\Api\Generals;

use App\Repositories\Interfaces\IBaseRepository;

interface IActivityRepository extends IBaseRepository
{
    public function createRequset($request);
}
