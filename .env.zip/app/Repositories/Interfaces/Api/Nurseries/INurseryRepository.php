<?php

namespace App\Repositories\Interfaces\Api\Nurseries;

use App\Repositories\Interfaces\IBaseRepository;

interface INurseryRepository extends IBaseRepository
{

    public function createRequset($request);
}
