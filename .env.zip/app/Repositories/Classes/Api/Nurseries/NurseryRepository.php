<?php

namespace App\Repositories\Classes\Api\Nurseries;

use App\Models\Api\Nurseries\BabysitterInfo;
use App\Models\Api\Nurseries\Nursery;
use App\Models\Api\Nurseries\PackageInfo;
use App\Repositories\Classes\BaseRepository;
use App\Repositories\Interfaces\Api\Nurseries\INurseryRepository;


class NurseryRepository extends BaseRepository implements INurseryRepository
{
    public function model()
    {
        return Nursery::class;
    }


    public function createPackages($packages, $nursery)
    {
        foreach ($packages as $package) {
            $savedPackage =  PackageInfo::create([
                'name' => $package['name'],
                'description' => $package['description'],
                'capacity' => $package['capacity'],
                'from_hour' => $package['from_hour'],
                'to_hour' => $package['to_hour'],
                'total_price' => $package['total_price'],
                'type_id' => $package['type_id'],
                'nursery_id' => $nursery['id'],
                'bundle_renew_after' => $package['bundle_renew_after'],
                'is_active' => $package['is_active'],
            ]);
            $savedPackage->days()->sync($package['days']);
        }
    }
    public function personalInfo($request, $nursery)
    {
        $babysitter =  BabysitterInfo::create([
            'years_of_experince' => $request['years_of_experince'],
            'date_of_birth' => $request['date_of_birth'],
            'academic_qualifications' => $request['academic_qualifications'],
            'user_id' => user()->id,
            'nursery_id' => $nursery['id'],
        ]);

        if (!empty($request['languages'])) $babysitter->languages()->sync($request['languages']);
        if (!empty($request['attachments'])) uploadAttachment($babysitter, $request, 'attachments', 'baby-sitter');
    }


    public function createRequset($request)
    {
        $nursery = $this->model->create([
            'name' => $request['name'],
            'capacity' => $request['capacity'],
            'acceptance_age' => $request['acceptance_age'],
            'country_id' => $request['country_id'],
            'city_id' => $request['city_id'],
            'neighborhood_id' => $request['neighborhood_id'],
            'street_number' => $request['street_number'],
            'address_description' => $request['address_description'],
            'latitude' => $request['latitude'],
            'longitude' => $request['longitude'],
            'disabilities_acceptance' => $request['disabilities_acceptance'],
            'is_active' => $request['is_active']
        ]);

        $this->personalInfo($request, $nursery);
        if (!empty($request['packages'])) $this->createPackages($request['packages'], $nursery);
        if (!empty($request['activities'])) $nursery->activities()->sync($request['activities']);
    }
}
