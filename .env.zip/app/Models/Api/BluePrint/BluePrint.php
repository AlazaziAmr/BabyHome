<?php

namespace App\Models\Api\BluePrint;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class BluePrint extends Model
{
    use HasFactory;
}
