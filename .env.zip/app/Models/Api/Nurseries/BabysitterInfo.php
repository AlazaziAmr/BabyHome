<?php

namespace App\Models\Api\Nurseries;

use App\Models\Api\Generals\Attachment;
use App\Models\Api\Generals\Language;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BabysitterInfo extends Model
{
    use HasFactory;
    protected $fillable = [
        'years_of_experince',
        'date_of_birth',
        'academic_qualifications',
        'user_id',
        'nursery_id',
    ];
    protected $casts = [
        'academic_qualifications' => 'array'
    ];

    /**
     * The languages that belong to the BabysitterInfo
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function languages(): BelongsToMany
    {
        return $this->belongsToMany(Language::class, 'babysitter_languages', 'babysitter_info_id', 'language_id');
    }

    public function attachmentable()
    {
        return $this->morphMany(Attachment::class, 'attachmentable');
    }
}
