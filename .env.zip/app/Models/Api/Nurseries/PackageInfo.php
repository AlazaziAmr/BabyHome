<?php

namespace App\Models\Api\Nurseries;

use App\Models\Api\Generals\Day;
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class PackageInfo extends BaseModel
{
    public $translatable = ['name'];

    protected $fillable = [
        'name',
        'description',
        'capacity',
        'from_hour',
        'to_hour',
        'total_price',
        'type_id',
        'nursery_id',
        'bundle_renew_after',
        'is_active',
    ];


    /**
     * The days that belong to the PackageInfo
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function days(): BelongsToMany
    {
        return $this->belongsToMany(Day::class, 'packages_available_days', 'package_id', 'day_id');
    }
}
