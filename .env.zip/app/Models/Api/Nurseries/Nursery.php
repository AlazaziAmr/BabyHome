<?php

namespace App\Models\Api\Nurseries;

use App\Models\Api\Generals\Activity;
use App\Models\Api\Generals\City;
use App\Models\Api\Generals\Country;
use App\Models\Api\Generals\Neighborhood;
use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Nursery extends BaseModel
{
    public $translatable = ['name'];

    protected $fillable = [
        'name',
        'capacity',
        'acceptance_age',
        'country_id',
        'city_id',
        'neighborhood_id',
        'street_number',
        'address_description',
        'latitude',
        'longitude',
        'disabilities_acceptance',
        'is_active'
    ];



        /**
     * Get the country that owns the Nursery
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }

    /**
     * Get the city that owns the Nursery
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function city(): BelongsTo
    {
        return $this->belongsTo(City::class, 'city_id', 'id');
    }

    /**
     * Get the neighborhood that owns the Nursery
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function neighborhood(): BelongsTo
    {
        return $this->belongsTo(Neighborhood::class, 'neighborhood_id', 'id');
    }


    /**
     * The activities that belong to the Nursery
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsToMany
     */
    public function activities(): BelongsToMany
    {
        return $this->belongsToMany(Activity::class, 'nursery_activities', 'nursery_id', 'activity_id');
    }
}
