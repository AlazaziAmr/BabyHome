<?php

namespace App\Models\Api\Generals;

use App\Models\BaseModel;

class Language extends BaseModel
{
    public $translatable = ['name'];

    protected $fillable = [
        'name',
        'logo'
    ];
}
