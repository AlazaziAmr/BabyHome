<?php

namespace App\Models\Api\Generals;

use App\Models\BaseModel;

class Day extends BaseModel
{

    public $translatable = ['name'];

}
