<?php

namespace App\Models\Api\Generals;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    use HasFactory;
    protected $fillable = ['id', 'mediaable_type', 'mediaable_id', 'storage', 'path'];
}
