<?php

namespace App\Models\Api\Generals;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Relations\BelongsTo;


class City extends BaseModel
{

    public $translatable = ['name'];

    protected $fillable = [
        'name',
        'country_id'
    ];


    /**
     * Get the country that owns the City
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function country(): BelongsTo
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }
}
