<?php

namespace App\Models\Api\Generals;

use App\Models\BaseModel;

class Activity extends BaseModel
{

    public $translatable = ['name'];

    protected $fillable = [
        'name',
        'description',
        'unit',
        'price',
        'is_paid',
        'is_active',
        'user_id',
    ];


    public function attachmentable()
    {
        return $this->morphMany(Attachment::class, 'attachmentable');
    }
}
