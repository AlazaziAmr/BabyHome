<?php

use App\Models\User;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

if (!function_exists('user')) {

    /**
     * get authenticated user
     *
     * @return User|\Illuminate\Contracts\Auth\Authenticatable|null
     */
    function user()
    {
        return auth()->check() ? auth()->user() : new User();
    }
}

if (!function_exists('admin')) {

    /**
     * get authenticated admin
     *
     * @return Admin|\Illuminate\Contracts\Auth\Authenticatable|null
     */
    function admin()
    {
        return auth('admin')->check() ? auth('admin')->user() : new Admin();
    }
}

if (!function_exists('clean_description')) {

    function clean_description($text)
    {
        return str_replace(["\r\n", '&nbsp;'], ' ', filter_var($text, FILTER_SANITIZE_STRING));
    }
}

if (!function_exists('OTPGenrator')) {

    /**
     * generate 5 digit for the sms code
     * @return int
     */
    function OTPGenrator()
    {
        return rand(10000, 99999);
    }
}

if (!function_exists('sendOTP')) {


    /**
     * send  OTP as Sms
     *
     * @param integer $OTP
     * @param string  $phone
     * @param string  $message
     */
    function sendOTP($OTP, $phone, $message = '')
    {
    }
}
if (!function_exists('sendOTP')) {


    /**
     * send  OTP as Sms
     *
     * @param integer $OTP
     * @param string  $phone
     * @param string  $message
     */
    function sendOTP($OTP, $phone, $message = '')
    {
    }
}
// if (!function_exists('executeBase64')) {

//     /**
//      * save base64
//      *
//      */
//     function executeBase64($model, $files, $destination = null)
//     {
//         foreach ($files as $file) {
//             if (preg_match('/^data:image\/(\w+);base64,/', $file)) {
//                 $extension = explode('/', explode(':', substr($file, 0, strpos($file, ';')))[1])[1];
//                 $replace = substr($file, 0, strpos($file, ',') + 1);
//                 $image = str_replace($replace, '', $file);
//                 $image = str_replace(' ', '+', $image);
//                 $imageName = Str::random(10) . '.' . $extension;
//                 Storage::disk('public')->put($imageName, base64_decode($image));
//                 $model->images()->create(['image' => $imageName, 'type' => $extension]);
//             }
//         }
//     }
// }

// if (!function_exists('uploadAttachment')) {
//     function uploadAttachment($model, $request, $fileName = 'attachments', $folderName = 'attachments')
//     {

//         if ($request->hasFile($fileName)) {
//             $attachments = $request->file($fileName);
//             foreach ($attachments as $attachment) {
//                 $extension = explode('/', mime_content_type($attachment['file']))[1];
//                $attachment['file'] = str_replace(' ', '+', $attachment['file']);
//                 $attachmentName = Str::random(10) . '.' . $extension;
//                 Storage::disk('public')->put($attachmentName, base64_decode($attachment['file']));
//                 $model->attachmentable()->create([
//                     'title' => $attachment['title'],
//                     'description' => $attachment['description'],
//                     'path' => $attachmentName,
//                 ]);
//             }
//         }
//     }
// }
if (!function_exists('uploadAttachment')) {
    function uploadAttachment($model, $request, $fileName = 'attachments', $folderName = 'attachments')
    {
        foreach ($request[$fileName] as $attachment) {
            $fileBaseName = str_replace(
                '.' . $attachment['file']->getClientOriginalExtension(),
                '',
                $attachment['file']->getClientOriginalName()
            );
            $newFileName = strtolower(time() . str_random(5) . '-' . str_slug($fileBaseName)) . '.' . $attachment['file']->getClientOriginalExtension();
            // $resizeFile = \Image::make($file->getRealPath());
            // $attachment['file']->save('storage/' . $folderName . '/' . $newFileName);

            Storage::disk('public')->put($folderName . '/' . $newFileName, $attachment['file']);

            $model->attachmentable()->create([
                'title' => $attachment['title'] ?? null,
                'description' => $attachment['description'],
                'path' => $newFileName,
            ]);
        }
    }
}
    // if (!function_exists('uploadImage')) {
    //     function uploadImage($request, $fileName = 'image', $folderName = 'images')
    //     {
    //         $file = $request->file($fileName);
    //         $fileBaseName = str_replace(
    //             '.' . $file->getClientOriginalExtension(),
    //             '',
    //             $file->getClientOriginalName()
    //         );
    //         $newFileName = strtolower(time() . str_random(5) . '-' . str_slug($fileBaseName)) . '.' . $file->getClientOriginalExtension();
    //         $resizeFile = \Image::make($file->getRealPath());
    //         $resizeFile->save('storage/' . $folderName . '/' . $newFileName);
    //         return asset('storage/' . $folderName . '/' . $newFileName);
    //     }
    // }

    // if (!function_exists('uploadImageWithReturnPath')) {
    //     function uploadImageWithReturnPath($request, $fileName = 'image', $folderName = 'images')
    //     {
    //         $file = $request->file($fileName);
    //         $fileBaseName = str_replace(
    //             '.' . $file->getClientOriginalExtension(),
    //             '',
    //             $file->getClientOriginalName()
    //         );
    //         $newFileName = strtolower(time() . str_random(5) . '-' . str_slug($fileBaseName)) . '.' . $file->getClientOriginalExtension();
    //         $resizeFile = \Image::make($file->getRealPath());
    //         $resizeFile->save('storage/' . $folderName . '/' . $newFileName);
    //         return public_path('storage/' . $folderName . '/' . $newFileName);
    //     }
    // }
