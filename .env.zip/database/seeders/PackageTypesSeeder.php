<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PackageTypesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                "name" => json_encode([
                    'ar' => 'ساعه',
                    'en' => 'hour',
                ]),

                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                "name" => json_encode([
                    'ar' => 'يومي',
                    'en' => 'dayly',
                ]),

                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                "name" => json_encode([
                    'ar' => 'أسبوعي',
                    'en' => 'weekly',
                ]),

                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                "name" => json_encode([
                    'ar' => 'شهري',
                    'en' => 'monthly',
                ]),

                'created_at' => now(),
                'updated_at' => now(),
            ],

        ];

        DB::table('packages_types')->insert($data);
    }
}
