<?php

namespace Database\Factories\Api\BluePrint;

use Illuminate\Database\Eloquent\Factories\Factory;

class BluePrintFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
